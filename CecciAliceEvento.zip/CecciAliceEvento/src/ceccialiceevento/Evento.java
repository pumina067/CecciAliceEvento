/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ceccialiceevento;

import java.util.Objects;



/**
 *
 * @author cecci.alice
 */
public class Evento {
    private String nomeEvento;
    private float prezzo;
    private int numeroBigliettiVenduti, numeroBigliettiResidui;
    
    /**
     * 
     * @param nomeEvento
     * @param prezzo
     * @param numeroBigliettiVenduti
     * @param numeroBigliettiResidui 
     */
    public Evento ( String nomeEvento, float prezzo, int numeroBigliettiVenduti, int numeroBigliettiResidui) {
        this.nomeEvento=nomeEvento;
        this.prezzo=prezzo;
        this.numeroBigliettiVenduti=numeroBigliettiVenduti;
        this.numeroBigliettiResidui=numeroBigliettiResidui;
        
    }
    /**
     * 
     * @param bigliettiDaVendere 
     */
    public void vendiBiglietti (int bigliettiDaVendere) {
        if ( this.numeroBigliettiResidui>= bigliettiDaVendere) {
         this.numeroBigliettiVenduti = this.numeroBigliettiVenduti+  bigliettiDaVendere ;
         this.numeroBigliettiResidui= this.numeroBigliettiResidui- bigliettiDaVendere;
        }
        
    }
    /**
     * 
     * @param bigliettiDaRistampare 
     */
    public void ristampaBiglietti (int bigliettiDaRistampare) {
        this.numeroBigliettiResidui= this.numeroBigliettiResidui+ bigliettiDaRistampare;
    }
    /**
     * 
     * @return 
     */
  public String getNomeEvento (){
    return this.nomeEvento;
    }
  /**
   * 
   * @return 
   */
    public float getPrezzo (){
    return this.prezzo;
    }
    /**
     * 
     * @return 
     */
    public int getNumeroBigliettiVenduti () {
          return this.numeroBigliettiVenduti;
    }
    /**
     * 
     * @return 
     */
    public int getNumeroBigliettiResidui () {
        return this.numeroBigliettiResidui;
    }
/**
 * 
 * @return 
 */
    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
/**
 * 
 * @param obj
 * @return 
 */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Evento other = (Evento) obj;
        if (Float.floatToIntBits(this.prezzo) != Float.floatToIntBits(other.prezzo)) {
            return false;
        }
        if (this.numeroBigliettiVenduti != other.numeroBigliettiVenduti) {
            return false;
        }
        if (this.numeroBigliettiResidui != other.numeroBigliettiResidui) {
            return false;
        }
        return Objects.equals(this.nomeEvento, other.nomeEvento);
    }

  
    /**
     * 
     * @return 
     */
    
    public String toString () {
        return "Nome evento: " + this.nomeEvento + "\nPrezzo: " + this.prezzo + "\nNumero biglietti venduti: " + this.numeroBigliettiVenduti + "\nNumero biglietti residui: " + 
                this.numeroBigliettiResidui;
           
    }
    /**
     * 
     * @param confronto 
     */
  public void stampaConfronto (boolean confronto) {
      if (confronto == true)
          System.out.println("I due eventi sono uguali");
      else   System.out.println("I due eventi sono diversi");
  }
  
}
    
    
    
    
    
    

