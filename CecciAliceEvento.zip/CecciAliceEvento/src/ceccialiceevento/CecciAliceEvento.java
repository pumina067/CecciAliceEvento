/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ceccialiceevento;

/**
 *
 * @author cecci.alice
 */
public class CecciAliceEvento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Evento e1 = new Evento ("festa", 12, 50, 10);
        Evento e2 = new Evento ("matrimonio", 12, 50, 20);
        
        System.out.println(e1.toString());
        e1.vendiBiglietti(10);
        e1.ristampaBiglietti(30);
        System.out.println(e1.toString());
        System.out.println(e2.toString());
        e1.vendiBiglietti(20);
        e1.ristampaBiglietti(55);
        System.out.println(e2.toString());
        e1.equals(e2);
        e1.stampaConfronto( e1.equals(e2));
    }
    
}
